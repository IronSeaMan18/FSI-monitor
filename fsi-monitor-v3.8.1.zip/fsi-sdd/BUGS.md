# FSI Monitor — Bug Tracker

## Fixed in v3.8.0
| ID | Sev | Description | Root cause | Fix |
|---|---|---|---|---|
| B-020 | HIGH | **False/duplicate vessels** | Bilbao names carry trailing `*` (provisional) + padding -> 2nd DB key for same ship | `clean_name()` strips markers; `norm_key()` dedupes; earliest ETA kept |
| B-021 | HIGH | "string did not match the expected pattern" | Bilbao ETAs are Spanish (`5 Ago`) -> JS `new Date()` Invalid Date | `parse_eta()` with ES+EN month maps -> ISO |
| B-001 | CRIT | `/api/shipnext` 33 s, returns empty flags | `resolve_flag()` did full DB read per IMO; VF blocked | in-memory cache + background resolver |
| B-002 | CRIT | Lost flag writes / corrupt JSON risk | 25 threads read-modify-write same file, no lock | `RLock` + atomic `tmp`+`os.replace` |
| B-003 | MED | UI shows "Runs: 0 / Last: never" | `/api/shipnext` never bumped `meta.runs` | shared `_fetch_endpoint()` calls `bump_run()` |
| B-004 | MED | KeyError on DB without `meta` | direct `db["meta"]["runs"]` | `setdefault` guards |
| B-005 | MED | Flag cache lost every restart | gitignored DB on ephemeral disk | committed `flags.json` seed (82 IMOs) |
| B-006 | MED | Cannot diagnose failures | bare `except:` in 8 places | typed `except Exception as e` + `log()` |
| B-007 | LOW | Dead IMOs retried every refresh | no negative cache | 24 h TTL negative cache |
| B-008 | HIGH | **Changed ETA never updated** | `merge_into_db` only filled empty fields | volatile fields always refresh |
| B-009 | MED | ETA sort wrong across sources | display strings sorted as text | `etaISO` field, sort on it |
| B-010 | LOW | Stale past arrivals shown as current | no ETA expiry | `hidePast` filter (default ON, toggleable) |
| B-011 | LOW | Port selection wiped each release | localStorage key bump | `lsMig()` migrates fsi12->fsi13 |
| B-012 | LOW | Errors scrolled away unseen | 3-line log only | persistent red error panel |
| B-013 | LOW | 12 ports fetched serially | sequential await loop | concurrency-4 parallel pool |
| B-014 | LOW | Cold start every visit | Render sleeps at 15 min | `/api/ping` keep-alive every 10 min |
| B-015 | LOW | Dead type filters | Catalan leftovers from Barcelona | removed |
| B-016 | MED | Anyone could poison flag cache | `CORS *` on `/api/saveflag` | CORS removed on write endpoint |
| B-017 | MED | Arbitrary strings written as flags | no validation | `^[A-Z]{2}$` + `^\d{7}$` IMO |
| B-018 | LOW | Silent breakage if ShipNext rotates IDs | no monitoring | `/api/health` probes all 9 ports |

## Open / known limitations
| ID | Description | Mitigation |
|---|---|---|
| B-100 | VesselFinder blocks Render IP | `flags.json` seed + background top-up; non-fatal |
| B-101 | Vilagarcía absent from ShipNext (VF-only) | needs alternate source |
| B-102 | ShipNext under-covers Ferrol (missed ANJI FOREVER, new 7-digit IMO) | VF supplement configured |
| B-103 | Bilbao publishes no IMO -> name keys | flags come inline from PA, so acceptable |
| B-104 | Render free tier: DB resets on redeploy | flags.json survives; vessel history does not |
